# Tunnelo

## Compilar
1. Abra a pasta no Android Studio (Koala ou mais novo) e aguarde o Gradle sincronizar.
2. Build > Build APK(s). Instale no celular.

## Servidor (VPS Ubuntu, ~US$5/mês)
    curl -O https://raw.githubusercontent.com/angristan/wireguard-install/master/wireguard-install.sh
    chmod +x wireguard-install.sh && sudo ./wireguard-install.sh
O script gera um .conf para o cliente. Cole no app em "Importar perfil".

## Uso
- Escolha a rede (Auto detecta Wi-Fi/operadora) e associe um perfil a cada uma.
- Toque no botão de ligar. Funciona em Wi-Fi e dados móveis.
