package app.tunnelo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Profile(val id: String, val name: String, val config: String, val network: String)

val CARRIERS = listOf("Wi-Fi", "Vivo", "Claro", "TIM", "Oi", "Outra")

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("tunnelo", Context.MODE_PRIVATE)

    fun profiles(): List<Profile> {
        val a = JSONArray(sp.getString("profiles", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Profile(o.getString("id"), o.getString("name"), o.getString("config"), o.optString("network", "Wi-Fi"))
        }
    }
    fun saveProfiles(l: List<Profile>) {
        val a = JSONArray(l.map { JSONObject().put("id", it.id).put("name", it.name).put("config", it.config).put("network", it.network) })
        sp.edit().putString("profiles", a.toString()).apply()
    }
    fun carrierMap(): Map<String, String> {
        val o = JSONObject(sp.getString("map", "{}"))
        return o.keys().asSequence().associateWith { o.getString(it) }
    }
    fun saveCarrierMap(m: Map<String, String>) { sp.edit().putString("map", JSONObject(m).toString()).apply() }

    var selectedCarrier: String
        get() = sp.getString("carrier", "Auto") ?: "Auto"
        set(v) = sp.edit().putString("carrier", v).apply()
    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()
    var userOs: String
        get() = sp.getString("userOs", "Android") ?: "Android"
        set(v) = sp.edit().putString("userOs", v).apply()
    var photoPath: String
        get() = sp.getString("photo", "") ?: ""
        set(v) = sp.edit().putString("photo", v).apply()
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) = sp.edit().putBoolean("onboarded", v).apply()
}
