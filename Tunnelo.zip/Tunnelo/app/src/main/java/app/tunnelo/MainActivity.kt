package app.tunnelo

import android.app.Activity
import android.graphics.BitmapFactory
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

private val Bg = Color(0xFF0B0F14); private val CardBg = Color(0xFF131A22)
private val Accent = Color(0xFF2DE2A6); private val Muted = Color(0xFF8A97A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = CardBg)) {
                val store = remember { Store(this) }
                var done by remember { mutableStateOf(store.onboarded) }
                if (!done) Onboarding(store) { store.onboarded = true; done = true }
                else Home(store) { store.onboarded = false; done = false }
            }
        }
    }
}

@Composable
fun Avatar(path: String, size: Dp) {
    val bmp = remember(path) {
        if (path.isEmpty()) null
        else BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
    }
    Box(Modifier.size(size).clip(CircleShape).background(CardBg), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.Person, null, tint = Muted, modifier = Modifier.size(size / 2))
    }
}

@Composable
fun Onboarding(store: Store, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    var step by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf(store.userName) }
    var photo by remember { mutableStateOf(store.photoPath) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val f = File(ctx.filesDir, "avatar_${System.currentTimeMillis()}.jpg")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            photo = f.absolutePath; store.photoPath = photo
        }
    }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TUNNELO", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text("Passo ${step + 1} de 3", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(32.dp))
        when (step) {
            0 -> {
                Text("Crie seu perfil", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(20.dp))
                Box(Modifier.clickable { pick.launch("image/*") }) { Avatar(photo, 110.dp) }
                TextButton(onClick = { pick.launch("image/*") }) { Text("Escolher foto") }
                OutlinedTextField(name, { name = it }, label = { Text("Seu nome") }, singleLine = true)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { store.userName = name.trim(); step = 1 }, enabled = name.isNotBlank()) { Text("Continuar") }
            }
            1 -> {
                Text("Qual seu sistema?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(20.dp))
                listOf("Android", "iOS").forEach { os ->
                    OutlinedButton(onClick = { store.userOs = os; step = 2 }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(os) }
                }
                Text("Este app roda só no Android. No iPhone, use o app oficial WireGuard com o mesmo arquivo .conf.",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
            }
            else -> {
                Text("Qual sua operadora?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(20.dp))
                CARRIERS.forEach { c ->
                    OutlinedButton(onClick = { store.selectedCarrier = c; onFinish() }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(c) }
                }
            }
        }
    }
}

@Composable
fun Home(store: Store, onEditProfile: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tState by TunnelManager.state.collectAsState()
    var profiles by remember { mutableStateOf(store.profiles()) }
    var map by remember { mutableStateOf(store.carrierMap()) }
    var carrier by remember { mutableStateOf(store.selectedCarrier) }
    var detected by remember { mutableStateOf(TunnelManager.detectNetwork(ctx)) }
    var error by remember { mutableStateOf<String?>(null) }
    var rx by remember { mutableStateOf(0L) }; var tx by remember { mutableStateOf(0L) }
    var showImport by remember { mutableStateOf(false) }

    val effective = if (carrier == "Auto") detected else carrier
    val visible = profiles.filter { it.network == effective }
    val profile = visible.firstOrNull { it.id == map[effective] } ?: visible.firstOrNull()
    val on = tState == Tunnel.State.UP

    fun connect() = scope.launch {
        error = null
        try {
            if (on) TunnelManager.down(ctx) else {
                // recalcula a rede AGORA, para não usar o servidor da rede anterior
                val net = TunnelManager.detectNetwork(ctx); detected = net
                val eff = if (carrier == "Auto") net else carrier
                val vis = profiles.filter { it.network == eff }
                val p = vis.firstOrNull { it.id == map[eff] } ?: vis.firstOrNull()
                    ?: throw IllegalStateException("Nenhum servidor para $eff")
                TunnelManager.up(ctx, p)
            }
        } catch (e: Exception) { error = e.message ?: "Falha ao conectar" }
    }
    val vpnPerm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) connect()
    }
    LaunchedEffect(on) { while (!on) { detected = TunnelManager.detectNetwork(ctx); delay(3000) } }
    LaunchedEffect(on) { while (on) { TunnelManager.stats(ctx).let { rx = it.first; tx = it.second }; delay(1000) } }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Avatar(store.photoPath, 44.dp)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(store.userName.ifBlank { "Olá" }, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("${store.userOs} · $effective", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onEditProfile) { Icon(Icons.Filled.Edit, null, tint = Muted) }
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(150.dp).clip(CircleShape).background(if (on) Accent.copy(.15f) else CardBg)
            .clickable {
                val i = VpnService.prepare(ctx)
                if (i != null && !on) vpnPerm.launch(i) else connect()
            }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.PowerSettingsNew, null, tint = if (on) Accent else Muted, modifier = Modifier.size(60.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(if (on) "Conectado" else "Desconectado", color = if (on) Accent else Muted, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }

        Spacer(Modifier.height(18.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Auto") + CARRIERS) { c ->
                FilterChip(selected = carrier == c, onClick = { carrier = c; store.selectedCarrier = c },
                    label = { Text(if (c == "Auto") "Auto ($detected)" else c) })
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(CardBg),
            border = BorderStroke(1.dp, Color(0xFF1F2A36))) {
            Column(Modifier.padding(16.dp)) {
                Text("SERVIDORES · $effective", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                if (visible.isEmpty()) Text("Nenhum servidor para esta rede. Importe um .conf.", color = Color.White, modifier = Modifier.padding(vertical = 8.dp))
                visible.forEach { p ->
                    Row(Modifier.fillMaxWidth().clickable { map = map + (effective to p.id); store.saveCarrierMap(map) },
                        verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = profile?.id == p.id, onClick = { map = map + (effective to p.id); store.saveCarrierMap(map) })
                        Text(p.name, color = Color.White, modifier = Modifier.weight(1f))
                        IconButton(onClick = { profiles = profiles - p; store.saveProfiles(profiles) }) { Icon(Icons.Filled.Delete, null, tint = Muted) }
                    }
                }
                TextButton(onClick = { showImport = true }) { Icon(Icons.Filled.Add, null); Text(" Adicionar servidor") }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Stat("DOWNLINK", rx); Stat("UPLINK", tx) }
    }

    if (showImport) ImportDialog(effective, { showImport = false }) { name, cfg, net ->
        profiles = profiles + Profile(UUID.randomUUID().toString(), name, cfg, net)
        store.saveProfiles(profiles); showImport = false
    }
}

@Composable
fun Stat(label: String, bytes: Long) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(label, color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
    Text(if (bytes > 1_048_576) "%.1f MB".format(bytes / 1_048_576.0) else "%.0f KB".format(bytes / 1024.0), color = Color.White, fontSize = 18.sp)
}

@Composable
fun ImportDialog(defaultNet: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var cfg by remember { mutableStateOf("") }
    var net by remember { mutableStateOf(defaultNet) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("Novo servidor WireGuard") },
        text = { Column {
            OutlinedTextField(name, { name = it }, label = { Text("Nome") }, singleLine = true)
            Text("Aparece em:", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(CARRIERS) { c -> FilterChip(selected = net == c, onClick = { net = c }, label = { Text(c) }) }
            }
            OutlinedTextField(cfg, { cfg = it }, label = { Text("Conteúdo do .conf") }, minLines = 5)
        } },
        confirmButton = { TextButton(onClick = { if (cfg.isNotBlank()) onSave(name.ifBlank { "Servidor" }, cfg, net) }) { Text("Salvar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
