package app.tunnelo

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

object TunnelManager {
    val state = MutableStateFlow(Tunnel.State.DOWN)
    private var backend: GoBackend? = null
    private val tunnel = object : Tunnel {
        override fun getName() = "tunnelo"
        override fun onStateChange(newState: Tunnel.State) { state.value = newState }
    }

    private fun backend(ctx: Context) =
        backend ?: GoBackend(ctx.applicationContext).also { backend = it }

    suspend fun up(ctx: Context, p: Profile) = withContext(Dispatchers.IO) {
        val cfg = Config.parse(p.config.byteInputStream())
        backend(ctx).setState(tunnel, Tunnel.State.UP, cfg)
    }

    suspend fun down(ctx: Context) = withContext(Dispatchers.IO) {
        backend(ctx).setState(tunnel, Tunnel.State.DOWN, null)
    }

    fun stats(ctx: Context): Pair<Long, Long> = try {
        val s = backend(ctx).getStatistics(tunnel)
        s.totalRx() to s.totalTx()
    } catch (e: Exception) { 0L to 0L }

    /** Detecta Wi-Fi ou operadora da rede física (ignora a própria VPN). */
    @Suppress("DEPRECATION")
    fun detectNetwork(ctx: Context): String {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.allNetworks.mapNotNull { cm.getNetworkCapabilities(it) }
            .filter { !it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) }
        if (caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) }) return "Wi-Fi"
        val name = ctx.getSystemService(TelephonyManager::class.java).networkOperatorName.lowercase()
        return CARRIERS.firstOrNull { it != "Wi-Fi" && it != "Outra" && name.contains(it.lowercase()) } ?: "Outra"
    }
}
